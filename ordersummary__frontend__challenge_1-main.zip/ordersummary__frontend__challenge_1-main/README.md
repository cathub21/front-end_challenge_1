# ordersummary__frontend__challenge_1
This is my submitted challenge to the https://www.frontendmentor.io/challenges/order-summary-component-QlPmajDUj/hub/order-summary-component-aqsmQ6MjR

It was fun testing out difference css styling. I am really starting to understand css and html and looking forward to adding some JavaScript soon.
